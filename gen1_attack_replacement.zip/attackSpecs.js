import { GEN1_TIMINGS, gen1MoveKey, getGen1AttackGeometry } from './gen1AttackGeometry.js';
// Frame-accurate attack specifications and collision geometry.
// Generation I moves are hand-authored to match the animation shapes exactly.

import { OLD_GEN_CHARS } from './eras.js';
import { HEROES } from './heroes.js';
import { VILLAINS } from './villains.js';
import { GUARDIANS } from './guardians.js';
import { DOWN_HEAVIES } from './downHeavies.js';
import { getGen2Hitboxes } from './gen2AttackAnims.js';
import { getGen3Hitboxes } from './gen3AttackAnims.js';
import { getGen4Hitboxes } from './gen4AttackAnims.js';
import { getGen5Hitboxes } from './gen5AttackAnims.js';
import { getGen5RestHitboxes } from './gen5RestAttackAnims.js';
import { getResonanceConstructHitboxes } from './resonanceConstructs.js';

const TAU = Math.PI * 2;

const CHAR_MAP = new Map([
  ...[...OLD_GEN_CHARS, ...HEROES, ...VILLAINS, ...GUARDIANS].map(c => [c.id, c]),
]);

const GEN1_MOVE_SPECS = {
 g1_fire:{
  us:{name:"Fire Hero's Rising",shape:'gen1Motion',range:95,knockback:'upContact',damage:6},
  ds:{name:"Fire Hero's Quake",shape:'gen1Motion',range:120,knockback:'downAway',damage:8},
  ss:{name:"Fire Hero's Wave",shape:'gen1Motion',range:95,knockback:'forwardContact',damage:8},
  uh:{name:'Ascendant Breaker',shape:'gen1Motion',range:125,knockback:'upContact',damage:14},
  dh:{name:'Sunder Slam',shape:'gen1Motion',range:140,knockback:'downAway',damage:17},
  sh:{name:'Rend Strike',shape:'gen1Motion',range:135,knockback:'forwardContact',damage:15},
  recovery:{name:'Return Return',shape:'gen1Motion',range:85,knockback:'upContact',damage:5},
  super:{name:'Ultimate: Flame Unleashed',shape:'gen1Motion',range:1120,knockback:'forwardContact',damage:28},
  groundPound:{name:'Meteor Pound',shape:'gen1Motion',range:150,knockback:'downAway',damage:9}
 },
 g1_grass:{
  us:{name:"Grass Hero's Rising",shape:'gen1Motion',range:95,knockback:'upContact',damage:8},
  ds:{name:"Grass Hero's Quake",shape:'gen1Motion',range:120,knockback:'downAway',damage:8},
  ss:{name:"Grass Hero's Wave",shape:'gen1Motion',range:95,knockback:'forwardContact',damage:6},
  uh:{name:'Ascendant Breaker',shape:'gen1Motion',range:125,knockback:'upContact',damage:15},
  dh:{name:'Sunder Slam',shape:'gen1Motion',range:140,knockback:'downAway',damage:16},
  sh:{name:'Rend Strike',shape:'gen1Motion',range:135,knockback:'forwardContact',damage:12},
  recovery:{name:'Return Return',shape:'gen1Motion',range:85,knockback:'upContact',damage:6},
  super:{name:'Ultimate: Growth Unleashed',shape:'gen1Motion',range:390,knockback:'forwardContact',damage:28},
  groundPound:{name:'Meteor Pound',shape:'gen1Motion',range:150,knockback:'downAway',damage:9}
 },
 g1_ice:{
  us:{name:"Ice Hero's Rising",shape:'gen1Motion',range:95,knockback:'upContact',damage:7},
  ds:{name:"Ice Hero's Quake",shape:'gen1Motion',range:120,knockback:'downAway',damage:9},
  ss:{name:"Ice Hero's Wave",shape:'gen1Motion',range:95,knockback:'forwardContact',damage:7},
  uh:{name:'Ascendant Breaker',shape:'gen1Motion',range:125,knockback:'upContact',damage:15},
  dh:{name:'Sunder Slam',shape:'gen1Motion',range:140,knockback:'downAway',damage:12},
  sh:{name:'Rend Strike',shape:'gen1Motion',range:135,knockback:'forwardContact',damage:18},
  recovery:{name:'Return Return',shape:'gen1Motion',range:85,knockback:'upContact',damage:7},
  super:{name:'Ultimate: Frost Unleashed',shape:'gen1Motion',range:310,knockback:'forwardContact',damage:27},
  groundPound:{name:'Meteor Pound',shape:'gen1Motion',range:150,knockback:'downAway',damage:10}
 },
 g1_thunder:{
  us:{name:"Thunder Hero's Rising",shape:'gen1Motion',range:95,knockback:'upContact',damage:8},
  ds:{name:"Thunder Hero's Quake",shape:'gen1Motion',range:120,knockback:'downAway',damage:5},
  ss:{name:"Thunder Hero's Wave",shape:'gen1Motion',range:95,knockback:'forwardContact',damage:7},
  uh:{name:'Ascendant Breaker',shape:'gen1Motion',range:125,knockback:'upContact',damage:12},
  dh:{name:'Sunder Slam',shape:'gen1Motion',range:140,knockback:'downAway',damage:15},
  sh:{name:'Rend Strike',shape:'gen1Motion',range:135,knockback:'forwardContact',damage:10},
  recovery:{name:'Return Return',shape:'gen1Motion',range:85,knockback:'upContact',damage:5},
  super:{name:'Ultimate: Lightning Unleashed',shape:'gen1Motion',range:320,knockback:'forwardContact',damage:35},
  groundPound:{name:'Meteor Pound',shape:'gen1Motion',range:150,knockback:'downAway',damage:10}
 },
 g1_water:{
  us:{name:"Water Hero's Rising",shape:'gen1Motion',range:95,knockback:'upContact',damage:6},
  ds:{name:"Water Hero's Quake",shape:'gen1Motion',range:120,knockback:'downAway',damage:9},
  ss:{name:"Water Hero's Wave",shape:'gen1Motion',range:95,knockback:'forwardContact',damage:5},
  uh:{name:'Ascendant Breaker',shape:'gen1Motion',range:125,knockback:'upContact',damage:10},
  dh:{name:'Sunder Slam',shape:'gen1Motion',range:140,knockback:'downAway',damage:11},
  sh:{name:'Rend Strike',shape:'gen1Motion',range:135,knockback:'forwardContact',damage:11},
  recovery:{name:'Return Return',shape:'gen1Motion',range:85,knockback:'upContact',damage:7},
  super:{name:'Ultimate: Tide Unleashed',shape:'gen1Motion',range:340,knockback:'watersuper',damage:33},
  groundPound:{name:'Meteor Pound',shape:'gen1Motion',range:150,knockback:'downAway',damage:9}
 }
};
// Grass / Ice / Water knockback now follows the written move data: grounded and airborne
// targets get different launch vectors (see specKnockbackVector: g1* profiles).
const GEN1_V2_KB={us:'g1UpSig',ds:'g1DownSig',ss:'g1SideSig',uh:'g1UpHeavy',dh:'g1DownHeavy',sh:'g1SideHeavy',recovery:'g1Recovery'};
for(const id of ['g1_grass','g1_ice','g1_water'])for(const [k,v] of Object.entries(GEN1_V2_KB))GEN1_MOVE_SPECS[id][k].knockback=v;
function normalizeProfile(value, fallback = 'forward') { const v = String(value || '').toLowerCase(); return v || fallback; }
function moveFromKey(char, key) {
  if (!char) return null;
  const k = String(key || '').toLowerCase();
  if (k === 'super' || k === 'sp') return char.superMove || null;
  if (k === 'side' || k === 'sidesignature' || k === 'ss') return char.signatures?.side || null;
  if (k === 'up' || k === 'upsignature' || k === 'us') return char.signatures?.up || null;
  if (k === 'down' || k === 'downsignature' || k === 'ds') return char.signatures?.down || null;
  if (k === 'upheavy' || k === 'upHeavy' || k === 'uh' || k === 'aerialheavy') return char.upHeavy || char.up_heavy || null;
  if (k === 'heavy' || k === 'sideheavy' || k === 'sh') return char.heavyAttack || null;
  if (k === 'downheavy' || k === 'dh') return char.downHeavy || char.down_heavy || DOWN_HEAVIES[char.id] || null;
  return null;
}
function inferKind(data) {
  if (data?.isSuper || data?.sigType === 'super') return 'super';
  if (data?.isHeavy || data?.sigType === 'heavy' || data?.sigType === 'downHeavy' || data?.sigType === 'upHeavy') return 'heavy';
  return 'signature';
}
function buildSpec(charId, data, moveKey = '') {
  if (!data) return null;
  const kind = inferKind(data);
  return { charId, kind, moveKey, name:data.name || moveKey, description:String(data.desc || data.description || ''), color:data.color, shape:normalizeProfile(data.hitboxProfile || data.type, 'forward'), knockback:normalizeProfile(data.knockbackProfile || data.knockbackType, 'forward'), range:Number(data.range) || 100, duration:Number(data.duration) || (kind === 'super' ? 26 : kind === 'heavy' ? 13 : 10), damage:Number(data.damage) || 0 };
}
export function getAttackSpec(charId, moveKey) {
  const char = CHAR_MAP.get(charId); if (!char) return null;
  return buildSpec(charId, moveFromKey(char, moveKey), moveKey);
}
export function getAttackSpecForData(charId, attackData) {
  if (!attackData) return null;
  if (GEN1_MOVE_SPECS[charId]) {
    const key = gen1MoveKey(charId, attackData);
    const override = GEN1_MOVE_SPECS[charId][key];
    if (override) { const frames=GEN1_TIMINGS[charId]?.[key] || [8,3,18]; return { charId, kind:key==='super'?'super':(['uh','dh','sh'].includes(key)?'heavy':'signature'), moveKey:key, color:attackData.color, startupFrames:frames[0], activeFrames:frames[1], endlagFrames:frames[2], duration:frames.reduce((a,b)=>a+b,0), ...override }; }
  }
  const char = CHAR_MAP.get(charId);
  if (!char) return null;
  if (attackData.hitboxProfile || attackData.knockbackProfile || attackData.desc) return buildSpec(charId, attackData, attackData.name || attackData.sigType || 'attack');
  let key = attackData.sigType || ''; if (attackData.isSuper) key = 'super'; else if (attackData.isHeavy) key = attackData.sigType === 'downHeavy' ? 'downHeavy' : 'heavy';
  return getAttackSpec(charId, key);
}
function clamp01(v) { return Math.max(0, Math.min(1, v)); }
function activeProgress(fighter) {
  const d=fighter?.attackData, id=fighter?.char?.id;
  if (String(id||'').startsWith('g1_') && d && d.type!=='attackHold' && !d.holding) {
    const key=gen1MoveKey(id,d), frames=GEN1_TIMINGS[id]?.[key];
    if(frames){
      const elapsed=Math.max(0,(Number(d.duration)||1)-(Number(fighter.attackTimer)||0));
      const [startup,active]=frames;
      // Collision uses the full normalized animation time so the shape and artwork
      // share the exact same per-frame coordinates.
      if(key==='ds' && id==='g1_fire'){
        if(elapsed>=startup&&elapsed<startup+2)return clamp01(d.progress||0);
        if(elapsed>=startup+8&&elapsed<startup+10)return clamp01(d.progress||0);
        return 0;
      }
      if(key==='groundPound'){
        const total=Number(d.duration)||frames.reduce((a,b)=>a+b,0);
        const directEnd=startup+Math.max(1,Math.floor(active*.45));
        const landingStart=Math.max(directEnd+1,Math.floor(total*.58));
        const landingEnd=landingStart+Math.max(1,active-(directEnd-startup));
        if((elapsed>=startup&&elapsed<directEnd)||(elapsed>=landingStart&&elapsed<landingEnd))return clamp01(d.progress||0);
        return 0;
      }
      if(elapsed<startup || elapsed>=startup+active) return 0;
      return clamp01(d.progress||0);
    }
  }
  return clamp01(d?.progress ?? 0);
}

export function getActiveSpecHitboxes(attacker) {
  const data = attacker?.attackData; if (!data) return [];
  // A confirmed hit consumes the current attack's hitbox. The animation and
  // recovery continue, but the collision shape disappears immediately.
  // Stage-based combo weapons manage their own per-stage/per-target hit tokens.
  if (data._hitboxConsumed || (data.hitApplied && !data.multiHitStages && !data.resonanceFamily)) return [];
  if (data.resonanceFamily) return getResonanceConstructHitboxes(attacker);
  const t = activeProgress(attacker); if (t <= 0 || t >= 1) return [];
  if (String(attacker?.char?.id || '').startsWith('g2_')) {
    let mk = data.sigType || data.moveKey || '';
    if (data.isSuper) mk = 'sp';
    else if (data.isHeavy) {
      if (mk === 'downHeavy' || mk === 'down' || data.isGroundPound) mk = 'dh';
      else if (mk === 'upHeavy' || mk === 'upheavy' || mk === 'aerialHeavy' || mk === 'aerial' || data.isAerialHeavy) mk = 'uh';
      else mk = 'sh';
    } else if (mk === 'up' || mk === 'upSignature') mk = 'us';
    else if (mk === 'down' || mk === 'downSignature') mk = 'ds';
    else mk = 'ss';
    const localBoxes = getGen2Hitboxes(attacker.char.id, mk, t, attacker.facing || 1);
    // Generation II hitboxes are authored in the same local coordinate space as
    // their attack drawings. Convert that local geometry into fighter/world
    // coordinates here; otherwise the overlay/collision system renders them at
    // the canvas origin (top-left).
    const ox = Number(attacker.x) || 0, oy = Number(attacker.y) || 0;
    return localBoxes.map(h => {
      if (h.shape === 'circle' || h.shape === 'box') return { ...h, x: ox + h.x, y: oy + h.y };
      if (h.shape === 'capsule') return { ...h, x1: ox + h.x1, y1: oy + h.y1, x2: ox + h.x2, y2: oy + h.y2 };
      if (h.shape === 'polygon') return { ...h, points: h.points.map(([px, py]) => [ox + px, oy + py]) };
      return h;
    });
  }
  if (String(attacker?.char?.id || '').startsWith('g3_')) {
    let mk = data.sigType || data.moveKey || '';
    if (data.isSuper) mk = 'sp';
    else if (data.isHeavy) {
      if (mk === 'downHeavy' || mk === 'down' || data.isGroundPound) mk = 'dh';
      else if (mk === 'upHeavy' || mk === 'upheavy' || mk === 'aerialHeavy' || mk === 'aerial' || data.isAerialHeavy) mk = 'uh';
      else mk = 'sh';
    } else if (mk === 'up' || mk === 'upSignature') mk = 'us';
    else if (mk === 'down' || mk === 'downSignature') mk = 'ds';
    else mk = 'ss';
    const localBoxes = getGen3Hitboxes(attacker.char.id, mk, t, attacker.facing || 1);
    const ox = Number(attacker.x) || 0, oy = Number(attacker.y) || 0;
    return localBoxes.map(h => {
      if (h.shape === 'circle' || h.shape === 'box') return { ...h, x: ox + h.x, y: oy + h.y };
      if (h.shape === 'capsule') return { ...h, x1: ox + h.x1, y1: oy + h.y1, x2: ox + h.x2, y2: oy + h.y2 };
      if (h.shape === 'polygon') return { ...h, points: h.points.map(([px, py]) => [ox + px, oy + py]) };
      return h;
    });
  }

  if (String(attacker?.char?.id || '').startsWith('g4_')) {
    let mk = data.sigType || data.moveKey || '';
    if (data.isSuper) mk = 'sp';
    else if (data.isHeavy) {
      if (mk === 'downHeavy' || mk === 'down' || data.isGroundPound) mk = 'dh';
      else if (mk === 'upHeavy' || mk === 'upheavy' || mk === 'aerialHeavy' || mk === 'aerial' || data.isAerialHeavy) mk = 'uh';
      else mk = 'sh';
    } else if (mk === 'up' || mk === 'upSignature') mk = 'us';
    else if (mk === 'down' || mk === 'downSignature') mk = 'ds';
    else mk = 'ss';
    const localBoxes = getGen4Hitboxes(attacker.char.id, mk, t, attacker.facing || 1);
    const ox = Number(attacker.x) || 0, oy = Number(attacker.y) || 0;
    return localBoxes.map(h => {
      if (h.shape === 'circle' || h.shape === 'box') return { ...h, x: ox + h.x, y: oy + h.y };
      if (h.shape === 'capsule') return { ...h, x1: ox + h.x1, y1: oy + h.y1, x2: ox + h.x2, y2: oy + h.y2 };
      if (h.shape === 'polygon') return { ...h, points: h.points.map(([px, py]) => [ox + px, oy + py]) };
      return h;
    });
  }

  if (['black','magenta','indigo','maroon','crimson','scarlet','white','silver','corpent','magneto','willow','cable','snodvor','kirsten','volt','temple','nightmare','hazel','whami','controller','evil','life','death','mercy'].includes(attacker?.char?.id)) {
    let mk = data.sigType || data.moveKey || '';
    if (data.isSuper) mk = 'sp';
    else if (data.isHeavy) {
      if (mk === 'downHeavy' || mk === 'down' || data.isGroundPound) mk = 'dh';
      else if (mk === 'upHeavy' || mk === 'upheavy' || mk === 'aerialHeavy' || mk === 'aerial' || data.isAerialHeavy) mk = 'uh';
      else mk = 'sh';
    } else if (mk === 'up' || mk === 'upSignature') mk = 'us';
    else if (mk === 'down' || mk === 'downSignature') mk = 'ds';
    else mk = 'ss';
    const localBoxes = getGen5RestHitboxes(attacker.char.id, mk, t, attacker.facing || 1);
    const ox = Number(attacker.x) || 0, oy = Number(attacker.y) || 0;
    return localBoxes.map(h => {
      if (h.shape === 'circle' || h.shape === 'box') return { ...h, x: ox + h.x, y: oy + h.y };
      if (h.shape === 'capsule') return { ...h, x1: ox + h.x1, y1: oy + h.y1, x2: ox + h.x2, y2: oy + h.y2 };
      if (h.shape === 'polygon') return { ...h, points: h.points.map(([px, py]) => [ox + px, oy + py]) };
      return h;
    });
  }
  if (['yellow','blue','purple','orange','green','pink','grey','turquoise','olive','copper','emerald','pearl','red','lavender','amber'].includes(attacker?.char?.id) || String(attacker?.char?.id || '').startsWith('g5_')) {
    let mk = data.sigType || data.moveKey || '';
    if (data.isSuper) mk = 'sp';
    else if (data.isHeavy) {
      if (mk === 'downHeavy' || mk === 'down' || data.isGroundPound) mk = 'dh';
      else if (mk === 'upHeavy' || mk === 'upheavy' || mk === 'aerialHeavy' || mk === 'aerial' || data.isAerialHeavy) mk = 'uh';
      else mk = 'sh';
    } else if (mk === 'up' || mk === 'upSignature') mk = 'us';
    else if (mk === 'down' || mk === 'downSignature') mk = 'ds';
    else mk = 'ss';
    const localBoxes = getGen5Hitboxes(attacker.char.id, mk, t, attacker.facing || 1);
    const ox = Number(attacker.x) || 0, oy = Number(attacker.y) || 0;
    return localBoxes.map(h => {
      if (h.shape === 'circle' || h.shape === 'box') return { ...h, x: ox + h.x, y: oy + h.y };
      if (h.shape === 'capsule') return { ...h, x1: ox + h.x1, y1: oy + h.y1, x2: ox + h.x2, y2: oy + h.y2 };
      if (h.shape === 'polygon') return { ...h, points: h.points.map(([px, py]) => [ox + px, oy + py]) };
      return h;
    });
  }

  const spec = data.spec || getAttackSpecForData(attacker.char?.id, data); if (!spec) return [];
  const f = attacker.facing || 1, x = attacker.x, y = attacker.y;
  const out = [];
  const C = (lx, ly, r) => out.push({shape:'circle', x:x + lx * f, y:y + ly, r});
  const B = (lx, ly, w, h) => out.push({shape:'box', x:x + lx * f, y:y + ly, w, h});
  const FB = (lx, ly, w, h) => out.push({shape:'box', x: f > 0 ? x + lx : x - lx - w, y:y + ly, w, h});
  const K = (x1,y1,x2,y2,r) => out.push({shape:'capsule', x1:x + x1*f, y1:y + y1, x2:x + x2*f, y2:y + y2, r});
  const P = pts => out.push({shape:'polygon', points:pts.map(([px,py]) => [x + px*f, y + py])});
  const q = t;
  if (String(attacker?.char?.id||'').startsWith('g1_') && spec.shape==='gen1Motion') {
    const key=gen1MoveKey(attacker.char.id,data);
    const local=getGen1AttackGeometry(attacker.char.id,key,clamp01(data.progress||0));
    for(const h of local){
      if(h.visualOnly) continue;
      if(h.shape==='circle') out.push({...h,x:x+(f>0?h.x:-h.x),y:y+h.y});
      else if(h.shape==='box') out.push({...h,x:x+(f>0?h.x:-h.x-h.w),y:y+h.y});
      else if(h.shape==='capsule') out.push({...h,x1:x+h.x1*f,y1:y+h.y1,x2:x+h.x2*f,y2:y+h.y2});
    }
    return out;
  }
  switch (spec.shape) {
    // Fire Hero hitboxes are measured to the authored move silhouettes and only
    // exist during the exact startup/active window stored on attackData.
    // Fire Hero: collision follows the moving flame/limb silhouette on each
    // active frame instead of using one oversized box for the entire move.
    case 'fireRise': {
      const cx = 18 + 10 * Math.sin(q * TAU), cy = -80 - 28 * q;
      const w=42+12*q,h=42+10*q; B(cx-w/2,cy-h/2,w,h); break;
    }
    case 'fireQuake': {
      // Two active windows: the first stomp, then the delayed ground eruption.
      const stageT = q < .5 ? clamp01((q-.125)*4) : clamp01((q-.625)*4);
      const spread=q<.5 ? 22+12*stageT : 40+18*stageT; K(24-spread,-1,24+spread,-1,7); C(24,-1,8+3*stageT); break;
    }
    case 'fireWave': {
      const cx = 28 + 45 * q, cy = -36 - 24 * Math.sin(Math.PI * q);
      // Capsules trace the visible flame slash from the wrist to its moving tip.
      K(17,-20,24,-28,6); K(24,-28,cx,cy,7);
      C(cx,cy,12 + 5 * Math.sin(Math.PI*q)); break;
    }
    case 'fireAscendant': {
      const cx = 10 + 12 * q, cy = -78 - 25 * q, w=48+16*q, h=60+10*q;
      B(cx-w/2, cy-h/2, w, h); break;
    }
    case 'fireSunder': {
      const spread = 30 + 45 * q;
      // The damaging floor shape is the same spreading contact line drawn by the slam.
      K(20-spread,-1,20+spread,-1,7 + 2*q); C(20,-1,12 + 8*q); break;
    }
    case 'fireRend': {
      const tip = 48 + 40 + 28*q, hy=-45;
      // Follow the visible palm/flame trail rather than a box beyond the hand.
      K(42,hy-3,60,hy-2,7); K(60,hy-2,tip,hy-4,8); C(tip,hy-4,16 + 5*Math.sin(Math.PI*q)); break;
    }
    case 'fireReturn': {
      // Two uneven pulses are visibly present together in the four-frame strike.
      B(16-19, -42-16, 38, 32);
      const w=28+18*q,h=24+10*q; B(20-w/2, -70-h/2, w, h);
      break;
    }
    case 'fireMeteor': {
      const cy = -25 + 18 * q, w=40+24*q, h=24+16*q;
      B(-w/2, cy-h/2, w, h);
      break;
    }
    case 'fireUltimate': {
      // Match the glowing projectile core; the long lance behind it is a trail, not a hitbox.
      const travel = clamp01(q);
      const cx = 40 + travel * 1080;
      C(cx, -58, 18 + 12 * travel);
      break;
    }
    // Thunder — Up Signature: ONLY the moving dot at the start of the circular line.
    case 'orbitPoint': { const a = -Math.PI/2 + (q < .92 ? q * TAU : TAU); C(Math.cos(a)*86, -112 + Math.sin(a)*34, 9); break; }
    case 'smallDome': { if (q < .18) break; const r=18 + Math.min(1,(q-.18)/.82)*35; for(let i=0;i<9;i++){const a=Math.PI+i/8*Math.PI; C(Math.cos(a)*r, -24+Math.sin(a)*r, 9);} break; }
    case 'forwardBolt': case 'forwardBoltHeavy': {
      const len = spec.shape === 'forwardBoltHeavy' ? 100 : 68; const cur = len * (.25 + .75*q);
      P([[24,-50],[24+cur*.23,-50-12],[24+cur*.14,-50],[24+cur*.52,-50-6],[24+cur*.42,-50+12],[24+cur*.82,-50],[24+cur*.62,-50-18],[24+cur,-50-6]]); break;
    }
    case 'threeBolts': { const top = -38 - 150*q; for(const dx of [24,82,140]) P([[dx-10,-38],[dx+10,-38],[dx+10,top],[dx-10,top]]); break; }
    case 'orbitBall': { const a=-Math.PI/2+q*TAU; C(20+Math.cos(a)*94,-72+Math.sin(a)*55,13); break; }
    case 'bottomBolt': { if(q < .35) break; P([[-15,-95],[15,-95],[9,-42],[14,-10],[-14,-10],[-9,-42]]); break; }
    case 'hook': {
      if(q<.14 || q>.86) break;
      const u=Math.max(0,Math.min(1,(q-.14)/.72));
      const a=-2.45+u*2.0, r=42+u*10;
      const ex=18+Math.cos(a)*r, ey=-48+Math.sin(a)*r;
      K(18,-48,18+r*.50*Math.cos(a*.55),-48+r*.50*Math.sin(a*.55),10);
      K(18+r*.50*Math.cos(a*.55),-48+r*.50*Math.sin(a*.55),ex,ey,10); C(ex,ey,12); break;
    }
    case 'stampFlames': {
      if(q<.28 || q>.88) break;
      const r=20+52*Math.min(1,(q-.28)/.60);
      for(let i=0;i<10;i++){const a=i/10*TAU; K(24,-3,24+Math.cos(a)*r,-3+Math.sin(a)*r*.62,6);}
      break;
    }
    case 'elbow': { if(q<.18||q>.86) break; K(20,-43,28+62*q,-43,15); C(28+62*q,-43,16); break; }
    case 'fireWheel': { const r=70; for(let i=0;i<16;i++){const a=i/16*TAU+q*TAU; C(Math.cos(a)*r,-92+Math.sin(a)*r*.52,10);} break; }
    case 'cracks': { if(q<.16) break; const r=18+60*Math.min(1,(q-.16)/.72); for(let i=0;i<12;i++){const a=i/12*TAU; K(24,-2,24+Math.cos(a)*r,-2+Math.sin(a)*r*.68,6);} break; }
    case 'gauntlet': {
      const u=q<.25?q/.25:1, d=q<.5?0:(q-.5)/.5; const cx=48+70*d, cy=-45-4*d; C(cx,cy,Math.max(10,20-10*d)); if(q<.55) K(18,-43,48,-45,13); break;
    }
    case 'explosion': {
      if(q<.18) break;
      const u=Math.min(1,(q-.18)/.82), cx=18+87*u, cy=-56-2*u;
      if(u<.62) C(cx,cy,10+18*u);
      else { const e=(u-.62)/.38, r=24+70*e; for(let i=0;i<14;i++){const a=i/14*TAU; K(cx,cy,cx+Math.cos(a)*r,cy+Math.sin(a)*r*.68,6);} }
      break;
    }
    case 'waterRing': {
      if(q<.14 || q>.86) break;
      const u=Math.max(0,Math.min(1,(q-.14)/.72));
      const z=u*3.2, i=Math.min(2,Math.floor(z)), e=z-i;
      const k=[[20,-54],[40,-72],[74,-100],[116,-120]], et=e*e*(3-2*e), a=k[i], b=k[Math.min(3,i+1)];
      const cx=a[0]+(b[0]-a[0])*et, cy=a[1]+(b[1]-a[1])*et;
      const rx=22-3*e, ry=11-2*e;
      for(let j=0;j<14;j++){const ang=j/14*TAU;C(cx+Math.cos(ang)*rx,cy+Math.sin(ang)*ry,5.5);}
      break;
    }
    case 'twinSplashes': {
      if(q<.22 || q>.90) break;
      const u=Math.max(0,Math.min(1,(q-.22)/.68)), e=u*u*(3-2*u);
      for(const side of [-1,1]){
        const pts=[];
        for(let i=0;i<=7;i++){const z=i/7;pts.push([side*(10+84*z*e),-3-Math.sin(z*Math.PI)*34*e]);}
        for(let i=0;i<pts.length-1;i++) K(pts[i][0],pts[i][1],pts[i+1][0],pts[i+1][1],9);
      }
      break;
    }
    case 'whipTip': {
      if(q<.20||q>.88) break;
      const u=Math.max(0,Math.min(1,(q-.20)/.68)),e=u*u*(3-2*u);
      const tx=42+92*e,ty=-55-30*Math.sin(e*Math.PI);
      C(tx,ty,10); break;
    }
    case 'waterRibbon': {
      const u=q;
      for(let lane=0;lane<3;lane++){
        for(let i=0;i<13;i++){
          const z=i/12,yy=-3-142*u*z,wob=Math.sin(z*TAU*(1.15+u*.8)+lane*2.1)*20,xx=(lane-1)*16+wob+((i%2)?-1:1)*8*z*u;
          if(i>0){const p0=(i-1)/12,py=-3-142*u*p0,px=(lane-1)*16+Math.sin(p0*TAU*(1.15+u*.8)+lane*2.1)*20+((i-1)%2?-1:1)*8*p0*u;K(px,py,xx,yy,7);}
        }
      }
      break;
    }
    case 'waterBounce': {
      if(q<.12) break;
      if(q<.62){const u=Math.min(1,(q-.12)/.50),e=u*u*(3-2*u); C(52,-55+58*e,22);}
      else {const u=Math.min(1,(q-.62)/.38),e=u*u*(3-2*u); const sx=52,sy=3; for(let i=0;i<11;i++){const a=Math.PI*1.05+i/10*Math.PI*.9; const ex=sx+Math.cos(a)*(18+46*e),ey=sy+Math.sin(a)*(10+34*e);K(sx,sy,ex,ey,6.5);} }
      break;
    }
    case 'crescent': {
      if(q<.10||q>.96) break;
      const u=Math.max(0,Math.min(1,(q-.10)/.86)),cx=34+28*u,cy=-48,r=56+18*Math.sin(u*Math.PI),start=-1.45+u*.15,end=.95+u*1.65;
      let prev=null;for(let i=0;i<=20;i++){const z=i/20,a=start+(end-start)*z,rr=r*(.78+.22*Math.sin(z*Math.PI)),px=cx+Math.cos(a)*rr,py=cy+Math.sin(a)*rr*.72;if(prev)K(prev[0],prev[1],px,py,10);prev=[px,py];}
      break;
    }
    case 'collapseRing': {
      // Only the outward-moving ring after the inward collapse is active.
      if(q<.55) break;
      const u=Math.min(1,(q-.55)/.45),e=u*u*(3-2*u),r=18+122*e;
      for(let i=0;i<22;i++){const a=i/22*TAU;C(Math.cos(a)*r,-62+Math.sin(a)*r*.68,7.5);}
      break;
    }
    case 'propellerLeaves': { if(q<.24 || q>.86) break; const u=Math.max(0,Math.min(1,(q-.24)/.62)), cy=-96+u*38, rot=u*TAU; for(let i=0;i<3;i++){const a=rot+i*TAU/3, cx=Math.cos(a)*31, sy=cy+Math.sin(a)*31*.38; P([[cx-7,sy-23],[cx+10,sy],[cx-7,sy+23]]);} break; }
    case 'thornTips': { if(q<.28||q>.88) break; const u=Math.max(0,Math.min(1,(q-.28)/.60)),e=u*u*(3-2*u); C(-22-26*e,-38+4*e,8); C(22+26*e,-38+4*e,8); break; }
    case 'branchEnd': { if(q<.12||q>.88) break; const u=Math.max(0,Math.min(1,(q-.12)/.76)),e=u*u*(3-2*u); B(14+92*e,-44,18,14); C(106*e+14,-44,9); break; }
    case 'grassDownHeavyBranch': {
      // First stick drops diagonally in the facing direction. After a confirmed
      // hit, the follow-up stick grows from its tip toward the rear of the hero.
      if(q < .10) break;
      const u=Math.max(0,Math.min(1,(q-.10)/.90)), e=u*u*(3-2*u);
      const endX=42+54*e, endY=-42+56*e;
      K(18,-48,endX,endY,9);
      if(q>.48 && data?.hitApplied){
        const v=Math.max(0,Math.min(1,(q-.48)/.52)), ev=v*v*(3-2*v);
        const backX=endX-(72*ev), backY=endY-(18*ev);
        K(endX,endY,backX,backY,8);
      }
      break;
    }
    case 'flowerPetals': { const u=q, r=20+62*u; for(let i=0;i<8;i++){const a=-Math.PI/2+i/8*TAU,px=Math.cos(a)*r,py=-68+Math.sin(a)*r*.68; P([[px-9,py-22],[px+14,py],[px-9,py+22]]);} break; }
    case 'vineTwoHits': { if(q<.20) break; if(q<.58) { const u=(q-.20)/.38; K(-12,-10,40+58*u,2+38*u,10); } else { const u=(q-.58)/.42; K(98-72*u,40-38*u,58-86*u,12-24*u,10); } break; }
    case 'branchSplit': { const len=120*Math.min(1,q/.72); P([[18,-48],[18+len,-55],[18+len,-41]]); if(q>.62){const s=(q-.62)/.38; for(const a of [-.32,0,.32]) P([[18+len,-48],[18+len+52*s,-48+Math.sin(a)*52*s],[18+len+60*s,-48+Math.sin(a)*52*s+6]]);} break; }
    case 'flowerSnap': { if(q<.4) break; const r=112-(q-.4)/.6*98; for(let i=0;i<12;i++){const a=i/12*TAU; P([[Math.cos(a)*r-10,-48+Math.sin(a)*r*.65-28],[Math.cos(a)*r+14,-48+Math.sin(a)*r*.65],[Math.cos(a)*r-10,-48+Math.sin(a)*r*.65+28]]);} break; }
    case 'throwingShard': { if(q<.18||q>.88) break; const u=Math.max(0,Math.min(1,(q-.18)/.70)),sx=10+34*u,sy=-96-72*u; P([[sx,sy-30],[sx+14,sy+12],[sx-8,sy+20],[sx-5,sy-8]]); break; }
    case 'plateShards': { if(q<.48) break; const u=Math.min(1,(q-.48)/.42); const cx=42,cy=-12; for(let i=0;i<8;i++){const a=-Math.PI*.92+i/7*Math.PI*1.08,rr=12+54*u,sx=cx+Math.cos(a)*rr,sy=cy+Math.sin(a)*rr*.62;P([[sx-7,sy-17],[sx+10,sy+5],[sx-8,sy+10]]);} break; }
    case 'forearmBlade': { if(q<.12||q>.90) break; const u=Math.max(0,Math.min(1,(q-.12)/.78)),a=-.18+u*.55; K(22,-48,22+Math.cos(a)*82,-48+Math.sin(a)*82,13); break; }
    case 'shardBurst': { const u=Math.min(1,q),startY=-108; for(let i=0;i<3;i++){const sx=(i-1)*30,sy=startY-72*u;K(sx,sy+24,sx,sy-20,8.5);} break; }
    case 'iceBlock': { const bx=50; if(q<.68) B(bx,-24,66,40); else {const u=Math.min(1,(q-.68)/.32);B(bx,-24,26,28);B(bx+34*u,-44-20*u,24,24);B(bx-20*u,8+14*u,24,22);} break; }
    case 'hammerArc': { if(q<.08) break; const u=Math.min(1,q/.92),a=-2.15+u*3.0; const ex=24+Math.cos(a)*92,ey=-52+Math.sin(a)*92;K(24,-52,ex,ey,18);if(q>.78){const e=(q-.78)/.22;for(let i=0;i<6;i++){const aa=.25+i*.18;C(ex+Math.cos(aa)*(12+22*e),ey+Math.sin(aa)*(10+18*e),5.5);}}break; }
    case 'crystalShards': { if(q<.38) break; const e=(q-.38)/.62, cx=52, cy=-54, r=24+e*110; for(let i=0;i<16;i++){const a=i/16*TAU; const sx=cx+Math.cos(a)*r, sy=cy+Math.sin(a)*r*.72; const nx=Math.cos(a), ny=Math.sin(a)*.72; P([[sx-8*nx,sy-8*ny],[sx+12*nx,sy+12*ny],[sx-5*nx+ny*6,sy-5*ny-nx*6]]);} break; }
    default: {
      const reach=Math.min(160,Math.max(50,spec.range)); K(24,-42,reach*q,-42,12);
    }
  }
  return out;
}

function pointRectDistance(px, py, rx, ry, rw, rh) {
  const cx=Math.max(rx-rw/2,Math.min(px,rx+rw/2)); const cy=Math.max(ry-rh/2,Math.min(py,ry+rh/2)); return Math.hypot(px-cx,py-cy);
}
function pointInPoly(px,py,pts){let inside=false; for(let i=0,j=pts.length-1;i<pts.length;j=i++){const [xi,yi]=pts[i],[xj,yj]=pts[j]; const hit=((yi>py)!==(yj>py))&&(px<(xj-xi)*(py-yi)/(yj-yi||1e-9)+xi); if(hit) inside=!inside;} return inside;}
function segIntersects(a,b,c,d){const cross=(p,q,r)=>(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]); const c1=cross(a,b,c),c2=cross(a,b,d),c3=cross(c,d,a),c4=cross(c,d,b); return ((c1===0&&onSeg(a,b,c))||(c2===0&&onSeg(a,b,d))||(c3===0&&onSeg(c,d,a))||(c4===0&&onSeg(c,d,b)))||(c1>0)!==(c2>0)&&(c3>0)!==(c4>0);}
function onSeg(a,b,p){return p[0]>=Math.min(a[0],b[0])-1e-6&&p[0]<=Math.max(a[0],b[0])+1e-6&&p[1]>=Math.min(a[1],b[1])-1e-6&&p[1]<=Math.max(a[1],b[1])+1e-6;}
function polygonHitsBody(poly, bx, by, bw, bh){
  const rect=[[bx-bw/2,by-bh/2],[bx+bw/2,by-bh/2],[bx+bw/2,by+bh/2],[bx-bw/2,by+bh/2]];
  if(poly.some(p=>pointInPoly(p[0],p[1],rect))) return true;
  if(rect.some(p=>pointInPoly(p[0],p[1],poly))) return true;
  for(let i=0;i<poly.length;i++) if(segIntersects(poly[i],poly[(i+1)%poly.length],rect[0],rect[1])||segIntersects(poly[i],poly[(i+1)%poly.length],rect[1],rect[2])||segIntersects(poly[i],poly[(i+1)%poly.length],rect[2],rect[3])||segIntersects(poly[i],poly[(i+1)%poly.length],rect[3],rect[0])) return true;
  return false;
}
export function hitboxIntersectsBody(hb, defender){
  // Matches the compact joint-driven reference-sheet body in renderer.js.
  const bw=34,bh=68,bx=defender.x,by=defender.y-34;
  if(hb.shape==='circle') return pointRectDistance(hb.x,hb.y,bx,by,bw,bh)<=hb.r;
  if(hb.shape==='box') return Math.abs(hb.x-bx)<=hb.w/2+bw/2 && Math.abs(hb.y-by)<=hb.h/2+bh/2;
  if(hb.shape==='polygon') return polygonHitsBody(hb.points,bx,by,bw,bh);
  if(hb.shape==='capsule') {
    const vx=hb.x2-hb.x1,vy=hb.y2-hb.y1,len2=vx*vx+vy*vy||1; const t=Math.max(0,Math.min(1,((bx-hb.x1)*vx+(by-hb.y1)*vy)/len2)); const px=hb.x1+vx*t,py=hb.y1+vy*t; return pointRectDistance(px,py,bx,by,bw,bh)<=hb.r;
  }
  return false;
}
function radialVector(attacker, defender){const dx=defender.x-attacker.x,dy=defender.y-attacker.y-0;const len=Math.hypot(dx,dy)||1;return{x:dx/len,y:dy/len};}
export function specKnockbackVector(attacker, defender, profile){
  const p=String(profile||'forward').toLowerCase(),f=attacker.facing||1;
  // Gen-I supers are authored as two-stage attacks: a setup/route hit followed
  // by a distinct finisher. Keep the launch vector tied to the stage actually hit.
  if(attacker?.char?.id?.startsWith('g1_') && attacker?.attackData?.isSuper){
    const id=attacker.char.id, stage=Number(attacker.attackData.hitStage)||0;
    if(id==='g1_fire') return {x:f,y:-0.08}; // long-range Flame projectile
    if(id==='g1_grass') return stage===0 ? {x:-f*.68,y:-.12} : {x:f*.82,y:-.68}; // pull/stagger, then diagonal lance
    if(id==='g1_ice') return stage===0 ? {x:f*.72,y:-.10} : {x:f*.76,y:-.62}; // traveling frost threat, then return strike
    if(id==='g1_thunder') return stage===0 ? {x:f*.52,y:-.22} : {x:f*.82,y:-.72}; // route hits converge into finisher
    if(id==='g1_water') return stage===0 ? {x:f*.48,y:-.18} : {x:f*.88,y:-.48}; // marked stagger then pressure cash-in
  }
  { // Gen-I v2 launch vectors (grounded vs airborne), per the move data
    const gr=!!defender.grounded, side=Math.sign((defender.x-attacker.x)||f);
    if(p==='g1upsig') return gr?{x:f*.30,y:-1}:{x:f*.08,y:-1};              // steep launch / vertical pop
    if(p==='g1downsig') return gr?{x:side*.62,y:-.55}:{x:side*.50,y:.90};   // trip-pop / spike then outward
    if(p==='g1sidesig') return gr?{x:f,y:-.10}:{x:f,y:-.32};                // shove / shallow outward angle
    if(p==='g1upheavy') return gr?{x:f*.10,y:-1.05}:{x:f*.66,y:-.88};       // high vertical / diagonal up-away
    if(p==='g1downheavy') return gr?{x:side*1.0,y:-.34}:{x:side*.16,y:1.0}; // strong horizontal pop / meteor
    if(p==='g1sideheavy') return gr?{x:f,y:-.30}:{x:f*.86,y:-.58};          // outward blast / diagonal away
    if(p==='g1recovery') return gr?{x:f*.40,y:-1}:{x:f*.58,y:-.78};         // pop up / lift with modest knockback
  }
  if(p==='up') return {x:f*.18,y:-1};
  if(p==='upcontact'){const dx=defender.x-attacker.x;return{x:Math.max(-.55,Math.min(.55,dx/90)),y:-1};}
  if(p==='downaway'){const dx=defender.x-attacker.x;const side=Math.sign(dx||f);return defender.grounded?{x:side*.95,y:-.28}:{x:side*.62,y:.92};}
  if(p==='radial'||p==='radialcontact') return radialVector(attacker,defender);
  if(p==='splitsplash'){ const dx=defender.x-attacker.x; return {x:Math.sign(dx||f),y:-.42}; }
  if(p==='waterbouncestage'){ const q=clamp01(attacker?.attackData?.progress||0); return q<.58 ? {x:f*.80,y:-.42} : {x:f*.20,y:-1}; }
  if(p==='bouncetwostage'){ const dy=defender.y-attacker.y; return dy>10 ? {x:f*.72,y:-.7} : {x:f*.18,y:-1}; }
  if(p==='watercrescent'){ const dx=defender.x-attacker.x, dy=defender.y-attacker.y; return {x:f*Math.max(.82,Math.min(1.0,1+dx/220)),y:Math.max(-.42,Math.min(.18,dy/180))}; }
  if(p==='crescentcontact'){ const dx=defender.x-attacker.x, dy=(defender.y-attacker.y); return {x:f*Math.max(.65,Math.min(1.0,1+dx/180)),y:Math.max(-.55,Math.min(.18,dy/160))}; }
  if(p==='watersuper'){ const dx=defender.x-attacker.x, dy=defender.y-attacker.y; const len=Math.hypot(dx,dy)||1; const topBias=Math.max(0,Math.min(1,(-dy+20)/150)); return {x:(dx/len)*(1-topBias*.25), y:(dy/len)*(1-topBias)+(-topBias*.55)}; }
  if(p==='inward'){const dx=attacker.x-defender.x,dy=attacker.y-defender.y,len=Math.hypot(dx,dy)||1;return{x:dx/len,y:dy/len};}
  if(p==='grassbehind') return {x:-f,y:-.18};
  if(p==='forwardcontact'){const dy=(defender.y-attacker.y)/90;return{x:f,y:Math.max(-.75,Math.min(.35,dy))};}
  if(p==='radialup'){const dx=defender.x-attacker.x;return{x:Math.max(-.8,Math.min(.8,dx/100)),y:-1};}
  if(p==='velocity'){const vx=attacker.vx||f,vy=attacker.vy||0,len=Math.hypot(vx,vy)||1;return{x:vx/len,y:vy/len};}
  return {x:f,y:-.38};
}
export function describeAttackSpec(spec){return spec?.description||'';}
